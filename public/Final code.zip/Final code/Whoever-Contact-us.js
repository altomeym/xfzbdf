let container = document.querySelector(".container");
let mainContainer = document.querySelector(".main-container");
let btnOne = document.querySelector(".btn-button");
let btnTwo = document.querySelector(".btn2-button");

btnOne.addEventListener("click", function () {
  mainContainer.classList.add("hide");
  container.classList.add("show");
});
btnTwo.addEventListener("click", function () {
  mainContainer.classList.remove("hide");
  container.classList.remove("show");
});
