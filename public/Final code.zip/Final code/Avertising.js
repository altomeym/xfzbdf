const decrementButton = document.getElementById("decrement");
const incrementButton = document.getElementById("increment");
const count = document.getElementById("count");

decrementButton.addEventListener("click", () => {
  count.innerText = parseInt(count.innerText, 10) - 1;
});

incrementButton.addEventListener("click", () => {
  count.innerText = parseInt(count.innerText, 10) + 1;
});
